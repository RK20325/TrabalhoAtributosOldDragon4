class Classe:
    def __init__(self, nome, dado_de_vida, habilidades):
        self.nome = nome
        self.dado_de_vida = dado_de_vida
        self.habilidades = habilidades